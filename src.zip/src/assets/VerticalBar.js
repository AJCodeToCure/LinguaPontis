import React from 'react'

const VerticalBar = () => {
  return (
    <svg width="2" height="42" viewBox="0 0 2 42" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path opacity="0.1" d="M1.00806 1L1.00806 41" stroke="black" stroke-width="2" stroke-linecap="round"/>
    </svg>
    
  )
}

export default VerticalBar