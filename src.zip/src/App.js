import AgencyUser from "./pages/agencyUser/AgencyUser";
import DashboardLayout from "./pages/dashboard/Dashboard";
import Login from "./pages/login/Login";

export default function App() {
  return (
  <div>
    {/* <DashboardLayout /> */}
    <Login />
    {/* <AgencyUser /> */}
  </div>
  )
}